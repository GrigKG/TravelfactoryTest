package TravelfactoryTest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravelfactoryTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(TravelfactoryTestApplication.class, args);
	}

}
